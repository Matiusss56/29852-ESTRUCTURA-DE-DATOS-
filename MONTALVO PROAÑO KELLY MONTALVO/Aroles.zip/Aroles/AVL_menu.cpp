// Archivo: AVL_menu.cpp
// Compilar en Visual Studio (Console App - C++)
#include <iostream>
#include <algorithm>
using namespace std;

struct Nodo {
    int key;
    Nodo* left;
    Nodo* right;
    int height;
    Nodo(int k) : key(k), left(nullptr), right(nullptr), height(1) {}
};

// ========== FUNCIONES AUXILIARES ==========

int altura(Nodo* n) {
    return n ? n->height : 0;
}

int factorEquilibrio(Nodo* n) {
    if (!n) return 0;
    return altura(n->left) - altura(n->right);
}

void actualizarAltura(Nodo* n) {
    if (n) n->height = 1 + max(altura(n->left), altura(n->right));
}

// Rotaciones
Nodo* rotacionDerecha(Nodo* y) {
    Nodo* x = y->left;
    Nodo* T2 = x->right;

    // Rotación
    x->right = y;
    y->left = T2;

    // Actualizar alturas
    actualizarAltura(y);
    actualizarAltura(x);

    return x; // nueva raíz
}

Nodo* rotacionIzquierda(Nodo* x) {
    Nodo* y = x->right;
    Nodo* T2 = y->left;

    // Rotación
    y->left = x;
    x->right = T2;

    // Actualizar alturas
    actualizarAltura(x);
    actualizarAltura(y);

    return y; // nueva raíz
}

// Buscar
bool buscar(Nodo* root, int key) {
    if (!root) return false;
    if (key == root->key) return true;
    if (key < root->key) return buscar(root->left, key);
    return buscar(root->right, key);
}

// Encontrar mínimo (usado en eliminar)
Nodo* minimo(Nodo* node) {
    Nodo* current = node;
    while (current && current->left) current = current->left;
    return current;
}

// ========== INSERTAR AVL ==========
Nodo* insertarAVL(Nodo* node, int key) {
    // 1) Inserción normal BST
    if (!node) return new Nodo(key);
    if (key < node->key)
        node->left = insertarAVL(node->left, key);
    else if (key > node->key)
        node->right = insertarAVL(node->right, key);
    else // duplicados no permitidos
        return node;

    // 2) Actualizar altura
    actualizarAltura(node);

    // 3) Obtener factor de equilibrio
    int balance = factorEquilibrio(node);

    // 4) Casos de rotación
    // Left Left
    if (balance > 1 && key < node->left->key)
        return rotacionDerecha(node);

    // Right Right
    if (balance < -1 && key > node->right->key)
        return rotacionIzquierda(node);

    // Left Right
    if (balance > 1 && key > node->left->key) {
        node->left = rotacionIzquierda(node->left);
        return rotacionDerecha(node);
    }

    // Right Left
    if (balance < -1 && key < node->right->key) {
        node->right = rotacionDerecha(node->right);
        return rotacionIzquierda(node);
    }

    return node;
}

// ========== ELIMINAR AVL ==========
Nodo* eliminarAVL(Nodo* root, int key) {
    if (!root) return root;

    // 1) Eliminación BST normal
    if (key < root->key)
        root->left = eliminarAVL(root->left, key);
    else if (key > root->key)
        root->right = eliminarAVL(root->right, key);
    else {
        // nodo encontrado
        // caso: un hijo o sin hijos
        if (!root->left || !root->right) {
            Nodo* child = root->left ? root->left : root->right;
            if (!child) {
                // Caso sin hijos
                delete root;
                root = nullptr;
            } else {
                // Caso un hijo
                Nodo* temp = root;
                root = child; // El hijo se convierte en la nueva raíz de este subárbol
                delete temp;  // Eliminar el nodo original
            }
        } else {
            // dos hijos: obtener sucesor (mínimo en subárbol derecho)
            Nodo* temp = minimo(root->right);
            root->key = temp->key;
            root->right = eliminarAVL(root->right, temp->key);
        }
    }

    // Si el árbol tuvo un solo nodo y fue eliminado
    if (!root) return root;

    // 2) Actualizar altura
    actualizarAltura(root);

    // 3) Factor de equilibrio
    int balance = factorEquilibrio(root);

    // 4) Casos de rotación para balancear
    // Left Left
    if (balance > 1 && factorEquilibrio(root->left) >= 0)
        return rotacionDerecha(root);

    // Left Right
    if (balance > 1 && factorEquilibrio(root->left) < 0) {
        root->left = rotacionIzquierda(root->left);
        return rotacionDerecha(root);
    }

    // Right Right
    if (balance < -1 && factorEquilibrio(root->right) <= 0)
        return rotacionIzquierda(root);

    // Right Left
    if (balance < -1 && factorEquilibrio(root->right) > 0) {
        root->right = rotacionDerecha(root->right);
        return rotacionIzquierda(root);
    }

    return root;
}

// ========== RECORRIDOS ODS ==========
void inorden(Nodo* root) {
    if (!root) return;
    inorden(root->left);
    cout << root->key << " ";
    inorden(root->right);
}

void preorden(Nodo* root) {
    if (!root) return;
    cout << root->key << " ";
    preorden(root->left);
    preorden(root->right);
}

void postorden(Nodo* root) {
    if (!root) return;
    postorden(root->left);
    postorden(root->right);
    cout << root->key << " ";
}

// ========== IMPRESIÓN GRÁFICA ASCII ==========
void imprimirGrafico(Nodo* root, int espacio = 0, int nivel = 8) {
    if (!root) return;
    espacio += nivel;
    imprimirGrafico(root->right, espacio);

    cout << endl;
    for (int i = nivel; i < espacio; ++i) cout << " ";
    cout << root->key << "\n";

    imprimirGrafico(root->left, espacio);
}

// ========== MENÚ Y VALIDACIONES ==========
void mostrarMenu() {
    cout << "\n==============================\n";
    cout << "      MENU ARBOL AVL\n";
    cout << "==============================\n";
    cout << "1) Insertar nodo\n";
    cout << "2) Buscar nodo\n";
    cout << "3) Eliminar nodo\n";
    cout << "4) Imprimir ODS (inorden/preorden/postorden)\n";
    cout << "5) Imprimir modo grafico (ASCII)\n";
    cout << "6) Salir\n";
    cout << "Seleccione opcion: ";
}

int main() {
    Nodo* root = nullptr;
    int opcion;
    int valor;

    do {
        mostrarMenu();
        cin >> opcion;

        if (cin.fail()) {
            cout << "Entrada invalida. Por favor, ingrese un numero.\n";
            cin.clear(); // Limpiar el estado de error de cin
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Descartar la entrada incorrecta
            continue; // Volver al inicio del bucle
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Limpiar el buffer para futuras lecturas

        switch (opcion) {
        case 1:
            cout << "Ingrese valor a insertar: ";
            cin >> valor;
            if (buscar(root, valor)) {
                cout << " El valor " << valor << " ya existe en el arbol.\n";
            } else {
                root = insertarAVL(root, valor);
                cout << "✔ Nodo insertado y balanceado.\n";
            }
            break;

        case 2:
            if (!root) {
                cout << " Arbol vacio. No hay nada que buscar.\n";
                break;
            }
            cout << "Ingrese valor a buscar: ";
            cin >> valor;
            cout << (buscar(root, valor) ? "✔ Valor encontrado.\n" : " Valor NO encontrado.\n");
            break;

        case 3:
            if (!root) {
                cout << " Arbol vacio. Nada que eliminar.\n";
                break;
            }
            cout << "Ingrese valor a eliminar: ";
            cin >> valor;
            if (!buscar(root, valor)) {
                cout << " El valor " << valor << " no existe en el arbol.\n";
            } else {
                root = eliminarAVL(root, valor);
                cout << "✔ Nodo eliminado y arbol re-balanceado.\n";
            }
            break;

        case 4:
            if (!root) {
                cout << " Arbol vacio. Nada que imprimir.\n";
                break;
            }
            cout << "\n--- INORDEN ---\n";
            inorden(root);
            cout << "\n\n--- PREORDEN ---\n";
            preorden(root);
            cout << "\n\n--- POSTORDEN ---\n";
            postorden(root);
            cout << "\n";
            break;

        case 5:
            if (!root) {
                cout << " Arbol vacio. Nada que mostrar.\n";
                break;
            }
            cout << "\n--- ARBOL (ASCII) ---\n";
            imprimirGrafico(root);
            cout << "\n";
            break;

        case 6:
            cout << "Saliendo...\n";
            break;

        default:
            cout << "Opcion invalida. Intente nuevamente.\n";
            break;
        }

    } while (opcion != 6);

    return 0;
}
